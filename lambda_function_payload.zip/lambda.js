var AWS = require('aws-sdk');
var autoscaling = new AWS.AutoScaling();

exports.handler = async (event) => {
    var params = {
        AutoScalingGroupName: 'example-asg',
        ShouldDecrementDesiredCapacity: true
    };
   
    autoscaling.setDesiredCapacity(params, function(err, data) {
        if (err) console.log(err, err.stack);
        else     console.log(data);
    });
};